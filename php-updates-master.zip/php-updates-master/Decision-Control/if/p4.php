<?php

//wap in php to find odd and even using single if

$n = readline('Enter the Number:');
if($n%2==0){
	echo " no is even \n";
	goto exit_label;
}
echo "no is Odd \n";
exit_label:;	





