<?php

//wap in php to find odd and even using single if

$n = readline('Enter the Number:');

($n%2) or exit('No is Even');
exit('No is Odd');









