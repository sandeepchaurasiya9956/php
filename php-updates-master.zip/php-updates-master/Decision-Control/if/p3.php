<?php

//wap in php to find odd and even using single if

$n = readline('Enter the Number:');
if($n%2==0){
	echo " no is even \n";
	exit;
}
echo "no is Odd \n";

//problem entire script will break;





