<?php


//wap in php to show normal execution of the program from top to Bottom.

