<?php 

//wap in php to show only valid 256 cases in switch 
 
echo "Running from switch \n";

$n = $argv[1];
switch($n){ 
case 1: 
echo "case 1 is executing \n";
case 2: 
echo "case 2 is executing \n";
case 3: 
echo "case 3 is executing \n";
case 4: 
echo "case 4 is executing \n";
case 5: 
echo "case 5 is executing \n";
case 6: 
echo "case 6 is executing \n";
case 7: 
echo "case 7 is executing \n";
case 8: 
echo "case 8 is executing \n";
case 9: 
echo "case 9 is executing \n";
case 10: 
echo "case 10 is executing \n";
case 11: 
echo "case 11 is executing \n";
case 12: 
echo "case 12 is executing \n";
case 13: 
echo "case 13 is executing \n";
case 14: 
echo "case 14 is executing \n";
case 15: 
echo "case 15 is executing \n";
case 16: 
echo "case 16 is executing \n";
case 17: 
echo "case 17 is executing \n";
case 18: 
echo "case 18 is executing \n";
case 19: 
echo "case 19 is executing \n";
case 20: 
echo "case 20 is executing \n";
case 21: 
echo "case 21 is executing \n";
case 22: 
echo "case 22 is executing \n";
case 23: 
echo "case 23 is executing \n";
case 24: 
echo "case 24 is executing \n";
case 25: 
echo "case 25 is executing \n";
case 26: 
echo "case 26 is executing \n";
case 27: 
echo "case 27 is executing \n";
case 28: 
echo "case 28 is executing \n";
case 29: 
echo "case 29 is executing \n";
case 30: 
echo "case 30 is executing \n";
case 31: 
echo "case 31 is executing \n";
case 32: 
echo "case 32 is executing \n";
case 33: 
echo "case 33 is executing \n";
case 34: 
echo "case 34 is executing \n";
case 35: 
echo "case 35 is executing \n";
case 36: 
echo "case 36 is executing \n";
case 37: 
echo "case 37 is executing \n";
case 38: 
echo "case 38 is executing \n";
case 39: 
echo "case 39 is executing \n";
case 40: 
echo "case 40 is executing \n";
case 41: 
echo "case 41 is executing \n";
case 42: 
echo "case 42 is executing \n";
case 43: 
echo "case 43 is executing \n";
case 44: 
echo "case 44 is executing \n";
case 45: 
echo "case 45 is executing \n";
case 46: 
echo "case 46 is executing \n";
case 47: 
echo "case 47 is executing \n";
case 48: 
echo "case 48 is executing \n";
case 49: 
echo "case 49 is executing \n";
case 50: 
echo "case 50 is executing \n";
case 51: 
echo "case 51 is executing \n";
case 52: 
echo "case 52 is executing \n";
case 53: 
echo "case 53 is executing \n";
case 54: 
echo "case 54 is executing \n";
case 55: 
echo "case 55 is executing \n";
case 56: 
echo "case 56 is executing \n";
case 57: 
echo "case 57 is executing \n";
case 58: 
echo "case 58 is executing \n";
case 59: 
echo "case 59 is executing \n";
case 60: 
echo "case 60 is executing \n";
case 61: 
echo "case 61 is executing \n";
case 62: 
echo "case 62 is executing \n";
case 63: 
echo "case 63 is executing \n";
case 64: 
echo "case 64 is executing \n";
case 65: 
echo "case 65 is executing \n";
case 66: 
echo "case 66 is executing \n";
case 67: 
echo "case 67 is executing \n";
case 68: 
echo "case 68 is executing \n";
case 69: 
echo "case 69 is executing \n";
case 70: 
echo "case 70 is executing \n";
case 71: 
echo "case 71 is executing \n";
case 72: 
echo "case 72 is executing \n";
case 73: 
echo "case 73 is executing \n";
case 74: 
echo "case 74 is executing \n";
case 75: 
echo "case 75 is executing \n";
case 76: 
echo "case 76 is executing \n";
case 77: 
echo "case 77 is executing \n";
case 78: 
echo "case 78 is executing \n";
case 79: 
echo "case 79 is executing \n";
case 80: 
echo "case 80 is executing \n";
case 81: 
echo "case 81 is executing \n";
case 82: 
echo "case 82 is executing \n";
case 83: 
echo "case 83 is executing \n";
case 84: 
echo "case 84 is executing \n";
case 85: 
echo "case 85 is executing \n";
case 86: 
echo "case 86 is executing \n";
case 87: 
echo "case 87 is executing \n";
case 88: 
echo "case 88 is executing \n";
case 89: 
echo "case 89 is executing \n";
case 90: 
echo "case 90 is executing \n";
case 91: 
echo "case 91 is executing \n";
case 92: 
echo "case 92 is executing \n";
case 93: 
echo "case 93 is executing \n";
case 94: 
echo "case 94 is executing \n";
case 95: 
echo "case 95 is executing \n";
case 96: 
echo "case 96 is executing \n";
case 97: 
echo "case 97 is executing \n";
case 98: 
echo "case 98 is executing \n";
case 99: 
echo "case 99 is executing \n";
case 100: 
echo "case 100 is executing \n";
case 101: 
echo "case 101 is executing \n";
case 102: 
echo "case 102 is executing \n";
case 103: 
echo "case 103 is executing \n";
case 104: 
echo "case 104 is executing \n";
case 105: 
echo "case 105 is executing \n";
case 106: 
echo "case 106 is executing \n";
case 107: 
echo "case 107 is executing \n";
case 108: 
echo "case 108 is executing \n";
case 109: 
echo "case 109 is executing \n";
case 110: 
echo "case 110 is executing \n";
case 111: 
echo "case 111 is executing \n";
case 112: 
echo "case 112 is executing \n";
case 113: 
echo "case 113 is executing \n";
case 114: 
echo "case 114 is executing \n";
case 115: 
echo "case 115 is executing \n";
case 116: 
echo "case 116 is executing \n";
case 117: 
echo "case 117 is executing \n";
case 118: 
echo "case 118 is executing \n";
case 119: 
echo "case 119 is executing \n";
case 120: 
echo "case 120 is executing \n";
case 121: 
echo "case 121 is executing \n";
case 122: 
echo "case 122 is executing \n";
case 123: 
echo "case 123 is executing \n";
case 124: 
echo "case 124 is executing \n";
case 125: 
echo "case 125 is executing \n";
case 126: 
echo "case 126 is executing \n";
case 127: 
echo "case 127 is executing \n";
case 128: 
echo "case 128 is executing \n";
case 129: 
echo "case 129 is executing \n";
case 130: 
echo "case 130 is executing \n";
case 131: 
echo "case 131 is executing \n";
case 132: 
echo "case 132 is executing \n";
case 133: 
echo "case 133 is executing \n";
case 134: 
echo "case 134 is executing \n";
case 135: 
echo "case 135 is executing \n";
case 136: 
echo "case 136 is executing \n";
case 137: 
echo "case 137 is executing \n";
case 138: 
echo "case 138 is executing \n";
case 139: 
echo "case 139 is executing \n";
case 140: 
echo "case 140 is executing \n";
case 141: 
echo "case 141 is executing \n";
case 142: 
echo "case 142 is executing \n";
case 143: 
echo "case 143 is executing \n";
case 144: 
echo "case 144 is executing \n";
case 145: 
echo "case 145 is executing \n";
case 146: 
echo "case 146 is executing \n";
case 147: 
echo "case 147 is executing \n";
case 148: 
echo "case 148 is executing \n";
case 149: 
echo "case 149 is executing \n";
case 150: 
echo "case 150 is executing \n";
case 151: 
echo "case 151 is executing \n";
case 152: 
echo "case 152 is executing \n";
case 153: 
echo "case 153 is executing \n";
case 154: 
echo "case 154 is executing \n";
case 155: 
echo "case 155 is executing \n";
case 156: 
echo "case 156 is executing \n";
case 157: 
echo "case 157 is executing \n";
case 158: 
echo "case 158 is executing \n";
case 159: 
echo "case 159 is executing \n";
case 160: 
echo "case 160 is executing \n";
case 161: 
echo "case 161 is executing \n";
case 162: 
echo "case 162 is executing \n";
case 163: 
echo "case 163 is executing \n";
case 164: 
echo "case 164 is executing \n";
case 165: 
echo "case 165 is executing \n";
case 166: 
echo "case 166 is executing \n";
case 167: 
echo "case 167 is executing \n";
case 168: 
echo "case 168 is executing \n";
case 169: 
echo "case 169 is executing \n";
case 170: 
echo "case 170 is executing \n";
case 171: 
echo "case 171 is executing \n";
case 172: 
echo "case 172 is executing \n";
case 173: 
echo "case 173 is executing \n";
case 174: 
echo "case 174 is executing \n";
case 175: 
echo "case 175 is executing \n";
case 176: 
echo "case 176 is executing \n";
case 177: 
echo "case 177 is executing \n";
case 178: 
echo "case 178 is executing \n";
case 179: 
echo "case 179 is executing \n";
case 180: 
echo "case 180 is executing \n";
case 181: 
echo "case 181 is executing \n";
case 182: 
echo "case 182 is executing \n";
case 183: 
echo "case 183 is executing \n";
case 184: 
echo "case 184 is executing \n";
case 185: 
echo "case 185 is executing \n";
case 186: 
echo "case 186 is executing \n";
case 187: 
echo "case 187 is executing \n";
case 188: 
echo "case 188 is executing \n";
case 189: 
echo "case 189 is executing \n";
case 190: 
echo "case 190 is executing \n";
case 191: 
echo "case 191 is executing \n";
case 192: 
echo "case 192 is executing \n";
case 193: 
echo "case 193 is executing \n";
case 194: 
echo "case 194 is executing \n";
case 195: 
echo "case 195 is executing \n";
case 196: 
echo "case 196 is executing \n";
case 197: 
echo "case 197 is executing \n";
case 198: 
echo "case 198 is executing \n";
case 199: 
echo "case 199 is executing \n";
case 200: 
echo "case 200 is executing \n";
case 201: 
echo "case 201 is executing \n";
case 202: 
echo "case 202 is executing \n";
case 203: 
echo "case 203 is executing \n";
case 204: 
echo "case 204 is executing \n";
case 205: 
echo "case 205 is executing \n";
case 206: 
echo "case 206 is executing \n";
case 207: 
echo "case 207 is executing \n";
case 208: 
echo "case 208 is executing \n";
case 209: 
echo "case 209 is executing \n";
case 210: 
echo "case 210 is executing \n";
case 211: 
echo "case 211 is executing \n";
case 212: 
echo "case 212 is executing \n";
case 213: 
echo "case 213 is executing \n";
case 214: 
echo "case 214 is executing \n";
case 215: 
echo "case 215 is executing \n";
case 216: 
echo "case 216 is executing \n";
case 217: 
echo "case 217 is executing \n";
case 218: 
echo "case 218 is executing \n";
case 219: 
echo "case 219 is executing \n";
case 220: 
echo "case 220 is executing \n";
case 221: 
echo "case 221 is executing \n";
case 222: 
echo "case 222 is executing \n";
case 223: 
echo "case 223 is executing \n";
case 224: 
echo "case 224 is executing \n";
case 225: 
echo "case 225 is executing \n";
case 226: 
echo "case 226 is executing \n";
case 227: 
echo "case 227 is executing \n";
case 228: 
echo "case 228 is executing \n";
case 229: 
echo "case 229 is executing \n";
case 230: 
echo "case 230 is executing \n";
case 231: 
echo "case 231 is executing \n";
case 232: 
echo "case 232 is executing \n";
case 233: 
echo "case 233 is executing \n";
case 234: 
echo "case 234 is executing \n";
case 235: 
echo "case 235 is executing \n";
case 236: 
echo "case 236 is executing \n";
case 237: 
echo "case 237 is executing \n";
case 238: 
echo "case 238 is executing \n";
case 239: 
echo "case 239 is executing \n";
case 240: 
echo "case 240 is executing \n";
case 241: 
echo "case 241 is executing \n";
case 242: 
echo "case 242 is executing \n";
case 243: 
echo "case 243 is executing \n";
case 244: 
echo "case 244 is executing \n";
case 245: 
echo "case 245 is executing \n";
case 246: 
echo "case 246 is executing \n";
case 247: 
echo "case 247 is executing \n";
case 248: 
echo "case 248 is executing \n";
case 249: 
echo "case 249 is executing \n";
case 250: 
echo "case 250 is executing \n";
case 251: 
echo "case 251 is executing \n";
case 252: 
echo "case 252 is executing \n";
case 253: 
echo "case 253 is executing \n";
case 254: 
echo "case 254 is executing \n";
case 255: 
echo "case 255 is executing \n";
case 256: 
echo "case 256 is executing \n";
case 257: 
echo "case 257 is executing \n";
case 258: 
echo "case 258 is executing \n";
default: 
echo "default case $n is executing \n";
}