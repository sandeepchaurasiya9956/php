<?php


// define('HOST','localhost:3308');
// define('USER','root');
// define('PASSWORD','');
// define('DBNAME','app2022');

return [

    'db:config' => [
        'host'=>'145.14.153.101',
        'user'=>'u323470395_vsfIs',
        'password'=>'5~+Fs@M1oK',
        'dbname'=>'u323470395_3VqkN',
    ]
    
];

?>
