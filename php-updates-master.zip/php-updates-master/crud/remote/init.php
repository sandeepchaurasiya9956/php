<?php

$settings = include __DIR__.'/setttings.php';