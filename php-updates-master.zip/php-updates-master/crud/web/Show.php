<html>

<head>
    <title>Show Records</title>
</head>

<body>
    <table style="width:100%" rules="all" border="1">
        <tr>
            <th>ID</th>
            <th>NAME</th>
            <th>Email</th>
        </tr>
        <tr>
            <td>1</td>
            <td>SURAJ KUMAR MISHRA</td>
            <td>surajmishra1872@gmail.com</td>
        </tr>
        <tr>
            <td>2</td>
            <td>Sourav Joshi</td>
            <td>sourav@gmail.com</td>
        </tr>
        
    </table>
</body>

</html>