<?php

//hello world
echo "Hello world";


?>