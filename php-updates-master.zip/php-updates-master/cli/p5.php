<?php

// Wap in php to show userdefined function

//declaration and definition
function wish(){
echo 'Hello Good Morning';
}

//using or calling
wish();





