<?php


// This is a inclusive php file

$x=10;
echo $x;
echo PHP_EOL;
?>

<h1>This is Code of Heading from HTML.</h1>