<?php

//wap in php to show userdefined procedural constants

define('gravity',10);
define('project_name','My_App');
define('DB_NAME','test_db');

echo gravity;
echo PHP_EOL;
echo project_name;
echo PHP_EOL;
echo DB_NAME;
echo PHP_EOL;