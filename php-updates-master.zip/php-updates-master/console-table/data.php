<?php

$records = [
	array('id'=>1001,'name'=>'ravi','email'=>'ravi@gmail.com'),
	array('id'=>1002,'name'=>'shivang','email'=>'shivang@gmail.com'),
	array('id'=>1003,'name'=>'pushpa','email'=>'pushpa@gmail.com'),
	array('id'=>1004,'name'=>'awnish','email'=>'awnish@gmail.com'),
	array('id'=>1005,'name'=>'srivalli','email'=>'srivalli@gmail.com'),
];