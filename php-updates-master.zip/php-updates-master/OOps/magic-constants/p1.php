<?php 

//wap in php to magic constants : __LINE__

echo "Executing the Line :".__LINE__.PHP_EOL;
echo "Executing the Line :".__LINE__.PHP_EOL;
echo "Executing the Line :".__LINE__.PHP_EOL;


