<?php

//wap in php to show, methods in PHP
// Any function inside class becomes method.

class Test{

function demo(){

echo 'I am a demo Function';

}

}

$test = new Test();
$test->demo();












