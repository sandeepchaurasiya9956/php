<?php

//wap in php to show null assignment type in parameterised constructor.

class Test{

public $a;
public $b;
public $c;

}

$test = new Test();
var_dump($test->a);
var_dump($test->b);
var_dump($test->c);
$a;
var_dump($a);










