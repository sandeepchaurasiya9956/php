<?php

//wap in PHP to show constructor in PHP.

class Test{

//explicit Costructor
public function __construct(){	
	
}


}

class Demo{

//implicit Constructor

}


$test = new Test();
$demo = new Demo();


