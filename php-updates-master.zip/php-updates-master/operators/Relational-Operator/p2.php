<?php

//wap in php to show Relational Operators
// type : In-equality

$a=20;
$b=10;

var_dump($a > $b);
var_dump($a < $b);

//not equal to  
// Not happen or never happen

var_dump($a != $b);
var_dump($a <> $b);

echo PHP_EOL;
var_dump(!($a==$b));
echo PHP_EOL;

$a=20;
$b=20;

var_dump($a > $b);
var_dump($a < $b);

//not equal to  
// Not happen or never happen

var_dump($a != $b);
var_dump($a <> $b);

