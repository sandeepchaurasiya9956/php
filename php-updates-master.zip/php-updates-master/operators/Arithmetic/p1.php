<?php

//wap in php to show Arithematic Operators


$x=readline('Enter the x value:');
$y=readline('Enter the y value:');

printf("The Addition = %d \n",$x + $y);
printf("The Subtraction = %d \n",$x - $y);
printf("The Multiplication = %d \n",$x * $y);
printf("The Division = %d \n",$x / $y);
//printf("The Remainder = %d \n",$x % $y);
printf("The power = %d \n",$x**$y);
