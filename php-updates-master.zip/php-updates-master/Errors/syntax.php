<?php
//wap in php to show syntax Error

$a=10
echo $a;
