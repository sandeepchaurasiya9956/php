<?php 
//wap in php to show warning error

include __DIR__.'/xyz.php';

$a=10;
echo $a;


