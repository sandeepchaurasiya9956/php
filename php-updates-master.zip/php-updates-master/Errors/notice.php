<?php
//wap in php to show Notice Error

echo $a; //Notice Error: undefined index a on line ___ filename notice.php

