
<?php

echo 'Message from b.php';
echo PHP_EOL;

