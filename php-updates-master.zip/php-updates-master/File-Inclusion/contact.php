<?php include __DIR__.'/layouts/header.php'; ?>

<H1>This is Contact Page</H1>

<?php include __DIR__.'/layouts/footer.php'; ?>