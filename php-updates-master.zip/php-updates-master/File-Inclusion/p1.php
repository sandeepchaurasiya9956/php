
<?php

//p1.php

echo 'Code from p1.php';
$a = 100;
echo PHP_EOL;

function test(){
echo 'test function from p1.php'.PHP_EOL;
}






